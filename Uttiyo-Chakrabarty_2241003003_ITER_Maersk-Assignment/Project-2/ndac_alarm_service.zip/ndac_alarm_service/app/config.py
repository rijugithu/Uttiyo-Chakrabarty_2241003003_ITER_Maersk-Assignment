from pydantic import BaseSettings
from typing import List
import os

class Settings(BaseSettings):
    NDAC_BASE_URL: str
    NDAC_API_KEY: str | None = None
    POLL_INTERVAL: int = 3600
    ALARM_SEVERITIES: List[str] = ["CRITICAL", "MAJOR"]

    DATABASE_URL: str = "sqlite+aiosqlite:///./ndac_alerts.db"

    SMTP_HOST: str | None = None
    SMTP_PORT: int | None = 587
    SMTP_USER: str | None = None
    SMTP_PASSWORD: str | None = None
    SMTP_FROM: str | None = "ndac-alerts@example.com"

    SENDGRID_API_KEY: str | None = None

    APP_HOST: str = "0.0.0.0"
    APP_PORT: int = 8080
    SECRET_KEY: str = "change-me"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

settings = Settings()
