from sqlalchemy import (
    Column, Integer, String, DateTime, JSON, Text, Boolean
)
from sqlalchemy.orm import declarative_base
import datetime

Base = declarative_base()

class Alarm(Base):
    __tablename__ = "alarms"
    id = Column(Integer, primary_key=True, index=True)
    ndac_alarm_id = Column(String, index=True, unique=True, nullable=False)
    alarm_type = Column(String)
    severity = Column(String, index=True)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)
    details = Column(JSON)
    notified = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class NotificationLog(Base):
    __tablename__ = "notification_logs"
    id = Column(Integer, primary_key=True, index=True)
    alarm_id = Column(Integer)  # foreign key could be added
    recipients = Column(Text)
    method = Column(String)  # smtp/sendgrid
    status = Column(String)
    response = Column(Text)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)

class Recipient(Base):
    __tablename__ = "recipients"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    email = Column(String, unique=True)
    active = Column(Boolean, default=True)

class Template(Base):
    __tablename__ = "templates"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True)
    subject = Column(String)
    body = Column(Text)
