import aiosmtplib
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
from tenacity import retry, wait_exponential, stop_after_attempt, retry_if_exception_type
import logging
from .config import settings

logger = logging.getLogger(__name__)

class Notifier:
    def __init__(self):
        self.smtp_configured = bool(settings.SMTP_HOST and settings.SMTP_USER and settings.SMTP_PASSWORD)
        self.sendgrid_configured = bool(settings.SENDGRID_API_KEY)

    @retry(wait=wait_exponential(multiplier=1, min=4, max=60), stop=stop_after_attempt(5))
    async def send_smtp(self, subject: str, body: str, recipients: list[str]) -> dict:
        if not self.smtp_configured:
            raise RuntimeError("SMTP not configured")
        message = f"Subject: {subject}\nFrom: {settings.SMTP_FROM}\nTo: {', '.join(recipients)}\n\n{body}"
        try:
            await aiosmtplib.send(message,
                                 hostname=settings.SMTP_HOST,
                                 port=settings.SMTP_PORT,
                                 username=settings.SMTP_USER,
                                 password=settings.SMTP_PASSWORD,
                                 start_tls=True)
            return {"status":"sent"}
        except Exception as e:
            logger.exception("SMTP send failed")
            raise

    @retry(wait=wait_exponential(multiplier=1, min=4, max=60), stop=stop_after_attempt(5))
    def send_sendgrid(self, subject: str, body: str, recipients: list[str]) -> dict:
        if not self.sendgrid_configured:
            raise RuntimeError("SendGrid not configured")
        message = Mail(
            from_email=settings.SMTP_FROM,
            to_emails=recipients,
            subject=subject,
            plain_text_content=body
        )
        try:
            client = SendGridAPIClient(settings.SENDGRID_API_KEY)
            resp = client.send(message)
            return {"status": "sent", "code": resp.status_code}
        except Exception as e:
            logger.exception("SendGrid failed")
            raise

    async def notify(self, subject: str, body: str, recipients: list[str]) -> dict:
        # Preference: SendGrid (API) if available, otherwise SMTP.
        if self.sendgrid_configured:
            return self.send_sendgrid(subject, body, recipients)
        elif self.smtp_configured:
            return await self.send_smtp(subject, body, recipients)
        else:
            raise RuntimeError("No notification method configured")
