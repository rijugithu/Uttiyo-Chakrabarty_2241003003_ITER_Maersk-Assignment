import httpx
from .config import settings
from typing import List, Dict, Any
import datetime
import logging

logger = logging.getLogger(__name__)

class NDACClient:
    def __init__(self, base_url: str, api_key: str | None = None):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key

    async def fetch_alarms(self) -> List[Dict[str, Any]]:
        """
        Query NDAC REST API for alarms. Assumes a response with a list of alarms.
        Structure depends on NDAC API. We normalize to:
        { "id": str, "type": str, "severity": str, "timestamp": ISOstr, "details": {...} }
        """
        url = f"{self.base_url}/alarms"
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        async with httpx.AsyncClient(timeout=30) as client:
            try:
                r = await client.get(url, headers=headers)
                r.raise_for_status()
                data = r.json()
                # Normalization step (update according to actual NDAC payload)
                return [self._normalize(a) for a in data.get("alarms", data)]
            except Exception as e:
                logger.exception("NDAC fetch failed, returning empty list")
                return []

    def _normalize(self, raw: Dict[str, Any]) -> Dict[str, Any]:
        # Attempt various common keys
        ndac_id = raw.get("id") or raw.get("alarm_id") or raw.get("uuid")
        severity = (raw.get("severity") or raw.get("level") or "").upper()
        atime = raw.get("timestamp") or raw.get("time") or raw.get("created_at")
        # try to parse timestamp or leave as string
        return {
            "id": str(ndac_id),
            "type": raw.get("type") or raw.get("alarm_type") or raw.get("name"),
            "severity": severity,
            "timestamp": atime,
            "details": raw,
        }
