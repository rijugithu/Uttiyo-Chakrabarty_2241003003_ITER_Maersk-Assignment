from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse
from ..db import get_db
from sqlalchemy.ext.asyncio import AsyncSession
from ..models import Alarm, NotificationLog, Recipient, Template
from sqlalchemy import select
from ..config import settings

router = APIRouter(prefix="/api/v1")

@router.get("/health")
async def health():
    return {"status": "ok", "time": __import__('datetime').datetime.utcnow().isoformat()}

@router.get("/alarms")
async def list_alarms(limit: int = 50, db: AsyncSession = Depends(get_db)):
    q = await db.execute(select(Alarm).order_by(Alarm.created_at.desc()).limit(limit))
    return [dict(
        id=a.id,
        ndac_alarm_id=a.ndac_alarm_id,
        severity=a.severity,
        timestamp=str(a.timestamp),
        notified=a.notified
    ) for a in q.scalars().all()]

@router.get("/history")
async def history(limit: int = 50, db: AsyncSession = Depends(get_db)):
    q = await db.execute(select(NotificationLog).order_by(NotificationLog.timestamp.desc()).limit(limit))
    return [dict(id=n.id, alarm_id=n.alarm_id, recipients=n.recipients, status=n.status, response=n.response, timestamp=str(n.timestamp)) for n in q.scalars().all()]
