from fastapi import APIRouter, Request, Form, Depends
from fastapi.templating import Jinja2Templates
from ..db import AsyncSessionLocal
from sqlalchemy import select
from ..models import Recipient, Template
from starlette.responses import RedirectResponse

templates = Jinja2Templates(directory="app/templates")
router = APIRouter()

@router.get("/")
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@router.get("/recipients")
async def recipients(request: Request):
    async with AsyncSessionLocal() as session:
        q = await session.execute(select(Recipient))
        recs = q.scalars().all()
    return templates.TemplateResponse("recipients.html", {"request": request, "recipients": recs})

@router.post("/recipients/add")
async def add_recipient(name: str = Form(...), email: str = Form(...)):
    async with AsyncSessionLocal() as session:
        r = Recipient(name=name, email=email, active=True)
        session.add(r)
        await session.commit()
    return RedirectResponse("/recipients", status_code=303)

@router.get("/history")
async def history(request: Request):
    async with AsyncSessionLocal() as session:
        q = await session.execute(select(Template))
        templates = q.scalars().all()
    return templates.TemplateResponse("history.html", {"request": request})
