import logging
import uvicorn
from fastapi import FastAPI
from .config import settings
from .scheduler import start_scheduler, process_alarms
from .api import api_v1, web
from .db import engine
import asyncio

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("ndac-alerts")

app = FastAPI(title="NDAC Alarm Notifier")

# include routers
app.include_router(api_v1.router)
app.include_router(web.router)

@app.on_event("startup")
async def startup_event():
    logger.info("Initializing DB (create tables if needed). Ensure migrate_db.py run or use Alembic)")
    # Optionally run create_all here if you prefer auto-create (or run migrate_db.py)
    # Schedule polling
    # run an immediate check once
    asyncio.create_task(process_alarms())
    start_scheduler()
    logger.info("Scheduler started")

@app.on_event("shutdown")
async def shutdown_event():
    logger.info("Shutting down...")

if __name__ == "__main__":
    uvicorn.run("app.main:app", host=settings.APP_HOST, port=settings.APP_PORT, reload=True)
