import asyncio
import logging
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from .ndac_client import NDACClient
from .config import settings
from .db import AsyncSessionLocal
from sqlalchemy import select
from .models import Alarm, NotificationLog, Recipient, Template
from .notifier import Notifier
import json
import datetime

logger = logging.getLogger(__name__)
ndac_client = NDACClient(settings.NDAC_BASE_URL, settings.NDAC_API_KEY)
notifier = Notifier()

async def process_alarms():
    logger.info("Polling NDAC for alarms...")
    alarms = await ndac_client.fetch_alarms()
    if not alarms:
        logger.info("No alarms returned")
        return

    async with AsyncSessionLocal() as session:
        for a in alarms:
            # filter severity
            if a.get("severity", "").upper() not in settings.ALARM_SEVERITIES:
                continue
            ndac_id = a["id"]
            # check if known
            q = await session.execute(select(Alarm).where(Alarm.ndac_alarm_id == ndac_id))
            existing = q.scalars().first()
            if existing:
                logger.debug("Alarm already recorded %s", ndac_id)
                continue
            # create alarm
            alarm = Alarm(
                ndac_alarm_id=ndac_id,
                alarm_type=a.get("type"),
                severity=a.get("severity"),
                timestamp=a.get("timestamp") or datetime.datetime.utcnow(),
                details=a.get("details")
            )
            session.add(alarm)
            await session.commit()
            await session.refresh(alarm)
            # load recipients
            q2 = await session.execute(select(Recipient).where(Recipient.active == True))
            recipients = [r.email for r in q2.scalars().all()]
            if not recipients:
                logger.warning("No active recipients configured - skipping notify")
                continue
            # choose template
            q3 = await session.execute(select(Template).where(Template.name == "default"))
            tpl = q3.scalars().first()
            subject = tpl.subject if tpl else f"NDAC Alarm: {alarm.alarm_type} [{alarm.severity}]"
            body = tpl.body if tpl else json.dumps(alarm.details, default=str)
            # Try to notify
            try:
                result = await notifier.notify(subject, body, recipients)
                # record notification
                nlog = NotificationLog(
                    alarm_id=alarm.id,
                    recipients=",".join(recipients),
                    method="sendgrid" if notifier.sendgrid_configured else "smtp",
                    status="sent",
                    response=str(result)
                )
                alarm.notified = True
                session.add(nlog)
                await session.commit()
            except Exception as e:
                logger.exception("Failed to notify recipients for alarm %s", alarm.ndac_alarm_id)
                nlog = NotificationLog(
                    alarm_id=alarm.id,
                    recipients=",".join(recipients),
                    method="sendgrid" if notifier.sendgrid_configured else "smtp",
                    status="failed",
                    response=str(e)
                )
                session.add(nlog)
                await session.commit()

def start_scheduler():
    scheduler = AsyncIOScheduler()
    scheduler.add_job(lambda: asyncio.create_task(process_alarms()), 'interval', seconds=settings.POLL_INTERVAL, next_run_time=None)
    scheduler.start()
    return scheduler
