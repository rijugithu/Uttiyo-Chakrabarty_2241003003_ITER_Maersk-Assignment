import asyncio
from app.ndac_client import NDACClient

async def test_normalize():
    client = NDACClient("http://example")
    raw = {"id": 123, "severity": "Critical", "type": "link-down", "timestamp": "2025-08-01T00:00:00Z"}
    n = client._normalize(raw)
    assert n["id"] == "123"
    assert n["severity"] == "CRITICAL"
