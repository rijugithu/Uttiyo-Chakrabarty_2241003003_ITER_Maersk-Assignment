package com.containerlte.coverageapp.utils

import android.content.Context
import android.util.Log

class NetworkScanner(private val context: Context) {
    fun startScan() {
        // Placeholder for TelephonyManager / vendor-specific APIs
        Log.d("NetworkScanner", "Starting LTE/5G scan...")
    }
}
