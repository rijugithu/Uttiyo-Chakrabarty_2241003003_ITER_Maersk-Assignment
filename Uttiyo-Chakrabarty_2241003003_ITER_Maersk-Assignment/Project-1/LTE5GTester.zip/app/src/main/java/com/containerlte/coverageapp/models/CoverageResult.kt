package com.containerlte.coverageapp.models

data class CoverageResult(
    val deviceId: String,
    val rssi: Int,
    val sinr: Int
)
