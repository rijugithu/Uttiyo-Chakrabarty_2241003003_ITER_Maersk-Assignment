package com.containerlte.coverageapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.containerlte.coverageapp.utils.NetworkScanner

class CoverageTestActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_coverage_test)

        val scanner = NetworkScanner(this)
        scanner.startScan()
    }
}
