package com.containerlte.coverageapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.containerlte.coverageapp.adapters.ResultAdapter
import com.containerlte.coverageapp.models.CoverageResult

class ResultViewActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result_view)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val sampleResults = listOf(
            CoverageResult("Device1", -85, 20),
            CoverageResult("Device2", -92, 14),
            CoverageResult("Device3", -78, 25)
        )

        recyclerView.adapter = ResultAdapter(sampleResults)
    }
}
