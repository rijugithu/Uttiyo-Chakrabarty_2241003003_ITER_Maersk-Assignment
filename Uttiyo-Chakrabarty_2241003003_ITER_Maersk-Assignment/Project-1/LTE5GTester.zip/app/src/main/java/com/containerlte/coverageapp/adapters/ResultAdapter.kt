package com.containerlte.coverageapp.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.containerlte.coverageapp.R
import com.containerlte.coverageapp.models.CoverageResult

class ResultAdapter(private val items: List<CoverageResult>) :
    RecyclerView.Adapter<ResultAdapter.VH>() {

    class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val deviceId: TextView = itemView.findViewById(R.id.tvDeviceId)
        val rssi: TextView = itemView.findViewById(R.id.tvRssi)
        val sinr: TextView = itemView.findViewById(R.id.tvSinr)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_result, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.deviceId.text = item.deviceId
        holder.rssi.text = "RSSI: ${item.rssi} dBm"
        holder.sinr.text = "SINR: ${item.sinr} dB"
    }

    override fun getItemCount() = items.size
}
