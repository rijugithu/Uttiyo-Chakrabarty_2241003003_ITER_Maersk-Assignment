# routes/project_routes.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
import schemas, crud, database, auth

router = APIRouter(prefix="/project", tags=["project"])

@router.post("/", response_model=schemas.KPIOut)
def add_kpi_record(kpi: schemas.KPICreate, current_user = Depends(auth.get_current_user), db: Session = Depends(database.get_db)):
    device = crud.get_device_by_id(db, kpi.device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    # Optionally ensure device belongs to user or user role
    return crud.create_kpi(db, kpi)

@router.post("/device", response_model=schemas.DeviceOut)
def register_device(device: schemas.DeviceCreate, current_user = Depends(auth.get_current_user), db: Session = Depends(database.get_db)):
    existing = crud.get_device_by_device_id(db, device.device_id)
    if existing:
        raise HTTPException(status_code=400, detail="Device with this ID already exists")
    return crud.create_device(db, device, user_id=current_user.id)

@router.get("/device", response_model=List[schemas.DeviceOut])
def list_devices(db: Session = Depends(database.get_db), current_user = Depends(auth.get_current_user)):
    return crud.list_devices_for_user(db, user_id=current_user.id)
