# routes/analytics_routes.py
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import Optional
import database, crud, auth
from statistics import mean

router = APIRouter(prefix="/analytics", tags=["analytics"])

@router.get("/weak-spots")
def weak_spots(rsrp_threshold: float = Query(-100.0), db: Session = Depends(database.get_db)):
    kpis = crud.get_recent_kpis(db, limit=2000)
    weak = [
        {"device_id": k.device_id, "timestamp": k.timestamp.isoformat(), "rsrp": k.rsrp, "cell_id": k.cell_id}
        for k in kpis
        if (k.rsrp is not None and k.rsrp < rsrp_threshold)
    ]
    return {"count": len(weak), "weak_spots": weak}

@router.get("/kpi-summary")
def kpi_summary(db: Session = Depends(database.get_db)):
    kpis = crud.get_recent_kpis(db, limit=1000)
    rsrps = [k.rsrp for k in kpis if k.rsrp is not None]
    sinrs = [k.sinr for k in kpis if k.sinr is not None]
    tdl = [k.throughput_dl for k in kpis if k.throughput_dl is not None]
    tul = [k.throughput_ul for k in kpis if k.throughput_ul is not None]

    return {
        "num_samples": len(kpis),
        "avg_rsrp": mean(rsrps) if rsrps else None,
        "avg_sinr": mean(sinrs) if sinrs else None,
        "avg_throughput_dl": mean(tdl) if tdl else None,
        "avg_throughput_ul": mean(tul) if tul else None
    }

@router.get("/recent-kpis")
def recent_kpis(limit: int = 100, db: Session = Depends(database.get_db)):
    kpis = crud.get_recent_kpis(db, limit=limit)
    return {"kpis": [ {
        "id": k.id,
        "device_id": k.device_id,
        "timestamp": k.timestamp.isoformat(),
        "rsrp": k.rsrp,
        "rsrq": k.rsrq,
        "sinr": k.sinr,
        "throughput_dl": k.throughput_dl,
        "throughput_ul": k.throughput_ul
    } for k in kpis ]}
