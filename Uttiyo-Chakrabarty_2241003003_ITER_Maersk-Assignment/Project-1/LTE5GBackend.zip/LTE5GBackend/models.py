# models.py
from sqlalchemy import Column, Integer, String, Float, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from datetime import datetime
from database import Base

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True, nullable=False)
    email = Column(String, unique=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    role = Column(String, default="engineer")
    devices = relationship("Device", back_populates="owner")

class Device(Base):
    __tablename__ = "devices"
    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(String, unique=True, index=True, nullable=False)
    name = Column(String, nullable=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    meta_info = Column(String, nullable=True)
    owner = relationship("User", back_populates="devices")
    kpis = relationship("KPIRecord", back_populates="device", cascade="all, delete-orphan")

class KPIRecord(Base):
    __tablename__ = "kpi_records"
    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(Integer, ForeignKey("devices.id"), nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False)
    rsrp = Column(Float, nullable=True)
    rsrq = Column(Float, nullable=True)
    sinr = Column(Float, nullable=True)
    rssi = Column(Float, nullable=True)
    throughput_dl = Column(Float, nullable=True)
    throughput_ul = Column(Float, nullable=True)
    cell_id = Column(String, nullable=True)
    latitude = Column(Float, nullable=True)
    longitude = Column(Float, nullable=True)
    extra = Column(String, nullable=True)

    device = relationship("Device", back_populates="kpis")
