# schemas.py
from pydantic import BaseModel
from typing import Optional
from datetime import datetime

# User
class UserCreate(BaseModel):
    username: str
    email: str
    password: str

class UserOut(BaseModel):
    id: int
    username: str
    email: str
    class Config:
        from_attributes = True

# Token
class Token(BaseModel):
    access_token: str
    token_type: str

# Device
class DeviceCreate(BaseModel):
    device_id: str
    name: Optional[str] = None
    meta_info: Optional[str] = None

class DeviceOut(BaseModel):
    id: int
    device_id: str
    name: Optional[str]
    meta_info: Optional[str]
    class Config:
        from_attributes = True

# KPI
class KPICreate(BaseModel):
    device_id: int
    timestamp: Optional[datetime] = None
    rsrp: Optional[float] = None
    rsrq: Optional[float] = None
    sinr: Optional[float] = None
    rssi: Optional[float] = None
    throughput_dl: Optional[float] = None
    throughput_ul: Optional[float] = None
    cell_id: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    extra: Optional[str] = None

class KPIOut(BaseModel):
    id: int
    device_id: int
    timestamp: datetime
    rsrp: Optional[float]
    rsrq: Optional[float]
    sinr: Optional[float]
    rssi: Optional[float]
    throughput_dl: Optional[float]
    throughput_ul: Optional[float]
    cell_id: Optional[str]
    latitude: Optional[float]
    longitude: Optional[float]
    extra: Optional[str]
    class Config:
        from_attributes = True
