# main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import database
from routes import user_routes, project_routes, analytics_routes

database.Base.metadata.create_all(bind=database.engine)

app = FastAPI(title="LTE/5G Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(user_routes.router)
app.include_router(project_routes.router)
app.include_router(analytics_routes.router)

@app.get("/")
def root():
    return {"message": "Backend is running"}
