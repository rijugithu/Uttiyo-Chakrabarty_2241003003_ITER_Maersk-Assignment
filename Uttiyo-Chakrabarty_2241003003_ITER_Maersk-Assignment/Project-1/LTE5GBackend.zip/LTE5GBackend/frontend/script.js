const baseURL = "http://127.0.0.1:8000";
let token = localStorage.getItem("access_token") || null;

function authHeader() {
  return token ? { "Authorization": `Bearer ${token}` } : {};
}

async function login() {
  const username = document.getElementById("login-username").value;
  const password = document.getElementById("login-password").value;
  const params = new URLSearchParams();
  params.append("username", username);
  params.append("password", password);
  const res = await fetch(`${baseURL}/users/login`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: params.toString()
  });
  const data = await res.json().catch(()=>({}));
  if (res.ok) {
    token = data.access_token;
    localStorage.setItem("access_token", token);
    document.getElementById("login-msg").innerText = "Logged in";
  } else {
    document.getElementById("login-msg").innerText = data.detail || "Login failed";
  }
}

async function registerUser() {
  const data = {
    username: document.getElementById("username").value,
    email: document.getElementById("email").value,
    password: document.getElementById("password").value
  };
  const res = await fetch(`${baseURL}/users/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  });
  const r = await res.json().catch(() => ({}));
  document.getElementById("register-msg").innerText = res.ok ? "Registered" : JSON.stringify(r);
}

async function registerDevice() {
  const data = {
    device_id: document.getElementById("device-id").value,
    name: document.getElementById("device-name").value,
    meta_info: document.getElementById("device-meta").value || null
  };
  const res = await fetch(`${baseURL}/project/device`, {
    method: "POST",
    headers: Object.assign({"Content-Type":"application/json"}, authHeader()),
    body: JSON.stringify(data)
  });
  const r = await res.json().catch(() => ({}));
  document.getElementById("device-msg").innerText = res.ok ? "Device registered" : JSON.stringify(r);
}

async function sendKPI() {
  const data = {
    device_id: parseInt(document.getElementById("kpi-device-id").value),
    rsrp: parseFloat(document.getElementById("kpi-rsrp").value) || null,
    sinr: parseFloat(document.getElementById("kpi-sinr").value) || null,
    throughput_dl: parseFloat(document.getElementById("kpi-tput").value) || null
  };
  const res = await fetch(`${baseURL}/project/`, {
    method: "POST",
    headers: Object.assign({"Content-Type":"application/json"}, authHeader()),
    body: JSON.stringify(data)
  });
  const r = await res.json().catch(()=>({}));
  document.getElementById("kpi-msg").innerText = res.ok ? "KPI sent" : JSON.stringify(r);
}

async function fetchWeakSpots() {
  const res = await fetch(`${baseURL}/analytics/weak-spots`);
  const data = await res.json();
  const list = document.getElementById("weak-list");
  list.innerHTML = "";
  (data.weak_spots || []).forEach(ws => {
    const li = document.createElement("li");
    li.textContent = `Device: ${ws.device_id}, RSRP: ${ws.rsrp}, cell: ${ws.cell_id}, time: ${ws.timestamp}`;
    list.appendChild(li);
  });
}

async function fetchRecentKpisAndUpdateChart() {
  const res = await fetch(`${baseURL}/analytics/recent-kpis?limit=30`);
  const data = await res.json();
  const list = document.getElementById("recent-kpis");
  list.innerHTML = "";
  const labels = [];
  const rsrpValues = [];
  (data.kpis || []).reverse().forEach(k => { // reverse so oldest->newest
    const li = document.createElement("li");
    li.textContent = `dev:${k.device_id} t:${k.timestamp} rsrp:${k.rsrp} dl:${k.throughput_dl}`;
    list.appendChild(li);
    labels.push(new Date(k.timestamp).toLocaleTimeString());
    rsrpValues.push(k.rsrp === null ? NaN : k.rsrp);
  });
  updateChart(labels, rsrpValues);
}

// Chart.js setup
const ctx = document.getElementById('rsrpChart').getContext('2d');
let rsrpChart = new Chart(ctx, {
  type: 'line',
  data: {
    labels: [],
    datasets: [{
      label: 'RSRP (dBm)',
      data: [],
      tension: 0.3,
      fill: false,
      borderWidth: 2
    }]
  },
  options: {
    scales: {
      y: { beginAtZero: false }
    }
  }
});

function updateChart(labels, data) {
  rsrpChart.data.labels = labels;
  rsrpChart.data.datasets[0].data = data;
  rsrpChart.update();
}

// Poll every 5s
setInterval(fetchRecentKpisAndUpdateChart, 5000);
fetchRecentKpisAndUpdateChart();
