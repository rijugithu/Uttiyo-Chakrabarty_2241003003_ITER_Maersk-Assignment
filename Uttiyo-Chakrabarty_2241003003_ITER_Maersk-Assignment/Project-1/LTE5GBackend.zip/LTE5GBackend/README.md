# NDAC Alerts

Run `python migrate_db.py` to create DB, then `uvicorn app.main:app --reload`.
