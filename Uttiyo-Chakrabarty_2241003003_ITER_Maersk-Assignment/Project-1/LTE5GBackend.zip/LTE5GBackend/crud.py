# crud.py
from sqlalchemy.orm import Session
import models, schemas, auth
from datetime import datetime

# Users
def create_user(db: Session, user: schemas.UserCreate):
    hashed_password = auth.hash_password(user.password)
    db_user = models.User(username=user.username, email=user.email, hashed_password=hashed_password)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def get_user_by_username(db: Session, username: str):
    return db.query(models.User).filter(models.User.username == username).first()

def get_user_by_id(db: Session, user_id: int):
    return db.query(models.User).filter(models.User.id == user_id).first()

# Devices
def create_device(db: Session, device: schemas.DeviceCreate, user_id: int | None = None):
    db_device = models.Device(device_id=device.device_id, name=device.name, meta_info=device.meta_info, user_id=user_id)
    db.add(db_device)
    db.commit()
    db.refresh(db_device)
    return db_device

def get_device_by_id(db: Session, device_id: int):
    return db.query(models.Device).filter(models.Device.id == device_id).first()

def get_device_by_device_id(db: Session, device_id_str: str):
    return db.query(models.Device).filter(models.Device.device_id == device_id_str).first()

def list_devices_for_user(db: Session, user_id: int):
    return db.query(models.Device).filter(models.Device.user_id == user_id).all()

# KPI records
def create_kpi(db: Session, kpi: schemas.KPICreate):
    db_kpi = models.KPIRecord(
        device_id=kpi.device_id,
        timestamp=kpi.timestamp or datetime.utcnow(),
        rsrp=kpi.rsrp,
        rsrq=kpi.rsrq,
        sinr=kpi.sinr,
        rssi=kpi.rssi,
        throughput_dl=kpi.throughput_dl,
        throughput_ul=kpi.throughput_ul,
        cell_id=kpi.cell_id,
        latitude=kpi.latitude,
        longitude=kpi.longitude,
        extra=kpi.extra
    )
    db.add(db_kpi)
    db.commit()
    db.refresh(db_kpi)
    return db_kpi

def get_recent_kpis(db: Session, limit: int = 100):
    return db.query(models.KPIRecord).order_by(models.KPIRecord.timestamp.desc()).limit(limit).all()

def get_kpis_for_device(db: Session, device_id: int, time_from=None, time_to=None):
    q = db.query(models.KPIRecord).filter(models.KPIRecord.device_id == device_id)
    if time_from:
        q = q.filter(models.KPIRecord.timestamp >= time_from)
    if time_to:
        q = q.filter(models.KPIRecord.timestamp <= time_to)
    return q.order_by(models.KPIRecord.timestamp.desc()).all()
